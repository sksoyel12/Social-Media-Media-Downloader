#!/usr/bin/env python3
"""
OmniDownloader — Production FastAPI Media Archiver & Multi-Engine Extractor
Supports Instagram (Reels, Multi-Slide Carousels, Base64 & Direct Highlights/Stories, 1080p Profile DPs),
TikTok (vt.tiktok.com / vm.tiktok.com Shortlinks, Unwatermarked HD Videos, Photo Slideshows, Audio, DPs),
and Pinterest (pin.it Shortlinks, /originals/ Master Images, Video Pins).
"""

import base64
import io
import json
import os
import re
import subprocess
import time
import uuid
import zipfile
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlencode, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from pydantic import BaseModel, Field

try:
    import yt_dlp  # type: ignore
    HAS_YTDLP = True
except ImportError:
    HAS_YTDLP = False

app = FastAPI(title="OmniDownloader API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DESKTOP_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
INSTAGRAM_EMBED_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
)
MOBILE_TIKTOK_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1"
)

TRACKING_PARAMS = {
    "cplk", "vrfl", "dlrf", "xtok", "exln", "rpxt", "img_index",
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "igsh", "igshid", "fbclid", "_r", "_t", "is_from_webapp", "sender_device",
    "web_id", "checksum", "tt_from", "share_app_id", "share_link_id", "share_item_id",
}

CACHE_TTL_SECONDS = 3600
RESULT_CACHE: Dict[str, Dict[str, Any]] = {}


class ExtractRequest(BaseModel):
    url: str
    mode: Optional[str] = Field(default="post")
    platform: Optional[str] = Field(default=None)


class HighlightRequest(BaseModel):
    url: str


class DownloadRequest(BaseModel):
    downloadId: Optional[str] = None
    url: Optional[str] = None
    filename: Optional[str] = None
    assetType: str = Field(default="media")
    mediaIndex: Optional[int] = 0
    format: str = Field(default="original")
    bitrate: int = Field(default=320)
    items: Optional[List[Dict[str, Any]]] = None


def prune_cache() -> None:
    now = time.time()
    expired = [k for k, v in RESULT_CACHE.items() if now - v.get("createdAt", 0) > CACHE_TTL_SECONDS]
    for k in expired:
        RESULT_CACHE.pop(k, None)


def safe_filename(name: str, ext: str) -> str:
    base = re.sub(r"[^\w\- ]+", "", (name or "omnidownloader-media").strip())
    base = re.sub(r"\s+", "-", base)[:60] or "omnidownloader-media"
    clean_ext = ext.lstrip(".") or "mp4"
    return f"{base}.{clean_ext}"


def is_generic_instagram_logo(url: Optional[str]) -> bool:
    if not url:
        return True
    lower = url.lower()
    return (
        "instagram_logo" in lower or
        "instagram-logo" in lower or
        "instagramlogo" in lower or
        "instagram_icon" in lower or
        "instagram-icon" in lower or
        "brand_assets" in lower or
        "brand-assets" in lower or
        "brandassets" in lower or
        "4168x4168" in lower or
        "static.cdninstagram.com" in lower or
        "/rsrc.php/" in lower or
        "/static/images/" in lower or
        "/static/rsrc/" in lower or
        "favicon" in lower or
        "ig_icon" in lower or
        "apple-touch-icon" in lower or
        "play-button" in lower or
        "transparent.png" in lower or
        "spacer.gif" in lower or
        "sprite" in lower or
        "glyph" in lower or
        "meta_logo" in lower or
        "instagram-app" in lower or
        "fbcdn.net/rsrc.php" in lower or
        "150x150" in lower or
        "100x100" in lower or
        bool(re.search(r"logo.*\.(?:png|jpg|jpeg|svg|webp)", lower)) or
        bool(re.search(r"instagram[_-]?(?:glyph|brand|icon|wordmark|logo)", lower))
    )


def is_authentic_story_media(url: Optional[str]) -> bool:
    if not url:
        return False
    if is_generic_instagram_logo(url):
        return False
    lower = url.lower()
    if "instagram_logo" in lower or "brand_assets" in lower or "static.cdninstagram.com" in lower or "/rsrc.php/" in lower or "/static/" in lower:
        return False
    if "cdninstagram.com" not in lower and "fbcdn.net" not in lower and "instagram." not in lower:
        return False
    return (
        ".mp4" in lower or
        ".jpg" in lower or
        ".jpeg" in lower or
        "/v/t51." in lower or
        "_nc_cat" in lower or
        "_nc_sid" in lower or
        "/o1/v/" in lower or
        "video" in lower
    )


def id_to_shortcode(id_str: Optional[str]) -> str:
    if not id_str:
        return ""
    try:
        clean = re.sub(r"\D+", "", str(id_str).split("_")[0])
        if not clean:
            return ""
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        n = int(clean)
        sc = ""
        while n > 0:
            rem = n % 64
            sc = alphabet[rem] + sc
            n //= 64
        return sc
    except Exception:
        return ""


def build_stream_url(raw_url: str, filename: Optional[str] = None, inline: bool = False) -> str:
    params: Dict[str, str] = {"url": raw_url}
    if filename:
        params["filename"] = filename
    if inline:
        params["inline"] = "1"
    return f"/api/stream?{urlencode(params)}"


def strip_tracking_params(url: str) -> Tuple[str, Optional[str]]:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query, keep_blank_values=False)
    story_media_id = qs.get("story_media_id", [None])[0]

    clean_qs = {
        k: v for k, v in qs.items()
        if k.lower() not in TRACKING_PARAMS and not k.lower().startswith("utm_")
    }
    host = (parsed.hostname or "").lower()
    if "instagram.com" in host and story_media_id and "/stories/" in parsed.path:
        clean_query = urlencode({"story_media_id": story_media_id})
    elif "instagram.com" in host or "tiktok.com" in host or "pinterest." in host:
        clean_query = ""
    elif "youtube.com" in host or "youtu.be" in host:
        v = qs.get("v", [None])[0]
        clean_query = urlencode({"v": v}) if v else ""
    else:
        clean_query = urlencode(clean_qs, doseq=True)

    cleaned = urlunparse((
        parsed.scheme or "https",
        parsed.netloc,
        parsed.path,
        parsed.params,
        clean_query,
        "",
    ))
    return cleaned, story_media_id


def decode_instagram_share_highlight(url: str) -> str:
    """/s/aGlnaGxpZ2h0OjE4MTQ0... -> base64 "highlight:<id>" -> /stories/highlights/<id>/ (keeps story_media_id)."""
    parsed = urlparse(url)
    match = re.match(r"^/s/([A-Za-z0-9+/=_-]+)", parsed.path)
    if not match:
        return url

    token = match.group(1).replace("-", "+").replace("_", "/")
    padded = token + "=" * ((4 - len(token) % 4) % 4)
    try:
        decoded = base64.b64decode(padded.encode("utf-8")).decode("utf-8", errors="ignore")
        if decoded.startswith("highlight:"):
            highlight_id = decoded.split(":", 1)[1].strip()
            if highlight_id.isdigit():
                sm = parse_qs(parsed.query).get("story_media_id", [None])[0]
                query = f"?{urlencode({'story_media_id': sm})}" if sm else ""
                return f"https://www.instagram.com/stories/highlights/{highlight_id}/{query}"
    except Exception:
        pass
    return url


def unshorten_url(raw_url: str) -> str:
    session = requests.Session()
    current = decode_instagram_share_highlight(raw_url.strip())

    if is_tiktok_shortlink(current):
        cleaned, _ = strip_tracking_params(unshorten_tiktok(current))
        return cleaned

    for hop in range(8):
        parsed = urlparse(current)
        host = (parsed.hostname or "").lower()

        if host in {"youtu.be"} or host.endswith(".youtu.be"):
            vid_id = parsed.path.lstrip("/").split("/")[0].split("?")[0]
            if vid_id:
                current = f"https://www.youtube.com/watch?v={vid_id}"
                break

        is_shortlink = (
            host in {"vt.tiktok.com", "vm.tiktok.com", "pin.it", "instagr.am", "youtu.be"}
            or host.endswith(".youtu.be")
            or parsed.path.startswith("/t/")
            or parsed.path.startswith("/s/")
        )
        if not is_shortlink:
            break

        if "instagram.com" in host and parsed.path.startswith("/s/"):
            decoded = decode_instagram_share_highlight(current)
            if decoded != current:
                current = decoded
                break

        headers = {
            "User-Agent": MOBILE_TIKTOK_UA if "tiktok" in host else DESKTOP_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        try:
            resp = session.get(current, headers=headers, allow_redirects=False, timeout=8)
            if resp.status_code in {301, 302, 303, 307, 308}:
                location = resp.headers.get("Location") or resp.headers.get("location")
                if location:
                    next_url = urljoin(current, location)
                    next_parsed = urlparse(next_url)
                    if "/accounts/login" in next_parsed.path:
                        qs = parse_qs(next_parsed.query)
                        if qs.get("next"):
                            current = urljoin("https://www.instagram.com", qs["next"][0])
                        break
                    if "tiktok.com" in (next_parsed.hostname or "") and (
                        "/about" in next_parsed.path or next_parsed.path in {"", "/"}
                    ):
                        break
                    current = next_url
                    continue
            elif resp.status_code == 200 and is_shortlink:
                html = resp.text[:30000]
                canonical = re.search(
                    r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']',
                    html,
                    re.I,
                ) or re.search(
                    r'href=["\'](https?://(?:www\.|m\.)?tiktok\.com/@(?:[^"\']+)/(?:video|photo|story)/\d+[^"\']*)["\']',
                    html,
                    re.I,
                )
                if canonical:
                    current = canonical.group(1).replace("&amp;", "&")
            break
        except Exception:
            break

    current = decode_instagram_share_highlight(current)
    cleaned, _ = strip_tracking_params(current)
    return cleaned


def detect_platform_and_route(
    raw_input: str,
    requested_mode: str = "post",
    requested_platform: Optional[str] = None,
) -> Dict[str, Any]:
    text = raw_input.strip()
    forced_profile = requested_mode == "profile"
    explicit_handle: Optional[str] = None

    if "://" not in text and re.match(r"^@?[\w.-]{1,60}$", text) and "/" not in text:
        explicit_handle = text.lstrip("@")
        forced_profile = True
        plat = requested_platform if requested_platform in {"instagram", "tiktok", "pinterest", "youtube"} else "instagram"
        if plat == "tiktok":
            text = f"https://www.tiktok.com/@{explicit_handle}"
        elif plat == "pinterest":
            text = f"https://www.pinterest.com/{explicit_handle}/"
        elif plat == "youtube":
            text = f"https://www.youtube.com/@{explicit_handle}"
        else:
            text = f"https://www.instagram.com/{explicit_handle}/"
    elif "://" not in text and re.match(
        r"^(?:www\.|m\.|vt\.|vm\.)?(?:instagram\.com|tiktok\.com|pinterest\.com|pin\.it|instagr\.am|youtube\.com|youtu\.be)/",
        text,
        re.I,
    ):
        text = f"https://{text}"

    resolved_url = unshorten_url(text)
    parsed = urlparse(resolved_url)
    host = (parsed.hostname or "").lower()

    platform: Optional[str] = None
    if "instagram.com" in host or "instagr.am" in host:
        platform = "instagram"
    elif "tiktok.com" in host:
        platform = "tiktok"
    elif "pinterest." in host or "pin.it" in host:
        platform = "pinterest"
    elif "youtube.com" in host or "youtu.be" in host:
        platform = "youtube"

    if not platform:
        raise HTTPException(status_code=400, detail="Unsupported link. Paste a public Instagram, TikTok, YouTube, or Pinterest URL.")

    parts = [p for p in parsed.path.split("/") if p]
    route_type = "post"
    handle: Optional[str] = explicit_handle

    if platform == "instagram":
        if len(parts) >= 2 and parts[0].lower() == "stories":
            if parts[1].lower() == "highlights":
                route_type = "highlight"
            else:
                route_type = "story"
                handle = parts[1].lstrip("@")
        elif len(parts) == 1 and parts[0].lower() not in {
            "p", "reel", "reels", "tv", "stories", "explore", "accounts", "direct", "share"
        }:
            route_type = "profile"
            handle = parts[0].lstrip("@")
    elif platform == "tiktok":
        if len(parts) == 1 and parts[0].startswith("@"):
            route_type = "profile"
            handle = parts[0].lstrip("@")
    elif platform == "pinterest":
        if len(parts) == 1 and parts[0].lower() not in {"pin", "search", "ideas"}:
            route_type = "profile"
            handle = parts[0].lstrip("@")
    elif platform == "youtube":
        if parts and parts[0].startswith("@"):
            route_type = "profile"
            handle = parts[0].lstrip("@")
        elif parts and parts[0] in {"channel", "c", "user"} and len(parts) > 1:
            route_type = "profile"
            handle = parts[1]

    if forced_profile:
        route_type = "profile"

    return {
        "url": resolved_url,
        "platform": platform,
        "routeType": route_type,
        "handle": handle,
    }


def compute_aspect_ratio(width: Optional[int], height: Optional[int], fallback: str = "vertical") -> str:
    if not width or not height:
        return fallback
    ratio = width / height
    if ratio < 0.85:
        return "vertical"
    if ratio > 1.15:
        return "horizontal"
    return "square"


def extract_hashtags(*texts: Optional[str]) -> List[str]:
    tags: List[str] = []
    seen = set()
    for t in texts:
        if not t:
            continue
        for match in re.findall(r"(?<!\w)#[\w\u0080-\uffff]+", t):
            if match.lower() not in seen:
                seen.add(match.lower())
                tags.append(match)
    return tags


def parse_srcset_best(srcset: str) -> Optional[str]:
    best_url = None
    best_w = -1
    for part in srcset.split(","):
        tokens = part.strip().split()
        if not tokens:
            continue
        candidate_url = tokens[0].replace("&amp;", "&")
        width = 0
        if len(tokens) > 1 and tokens[1].endswith("w"):
            try:
                width = int(tokens[1][:-1])
            except ValueError:
                width = 0
        if width >= best_w:
            best_w = width
            best_url = candidate_url
    return best_url


def extract_with_ytdlp_fallback(url: str) -> Optional[Dict[str, Any]]:
    if not HAS_YTDLP:
        return None
    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "extract_flat": False,
        "http_headers": {"User-Agent": DESKTOP_UA},
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return None
            title = info.get("title") or "Social Media Post"
            caption = info.get("description") or title
            uploader = info.get("uploader") or info.get("channel")
            uploader_id = (info.get("uploader_id") or "").lstrip("@") or None
            thumb = info.get("thumbnail")
            entries = info.get("entries") or [info]
            media: List[Dict[str, Any]] = []
            for idx, entry in enumerate(entries):
                m_url = entry.get("url")
                if not m_url and entry.get("formats"):
                    formats = [f for f in entry["formats"] if f.get("url")]
                    if formats:
                        m_url = formats[-1]["url"]
                if not m_url:
                    continue
                ext = entry.get("ext") or "mp4"
                is_vid = ext in {"mp4", "webm", "mov"} or entry.get("vcodec") not in {None, "none"}
                w = entry.get("width") or 1080
                h = entry.get("height") or (1920 if is_vid else 1080)
                media.append({
                    "url": build_stream_url(m_url, safe_filename(f"{title}-{idx+1}", ext), True),
                    "rawUrl": m_url,
                    "downloadUrl": build_stream_url(m_url, safe_filename(f"{title}-{idx+1}", ext), False),
                    "thumbnail": build_stream_url(thumb, "thumb.jpg", True) if thumb else None,
                    "type": "video" if is_vid else "image",
                    "quality": f"{h}p HD" if is_vid else "Original HD",
                    "format": "mp4" if is_vid else "jpg",
                    "width": w,
                    "height": h,
                    "aspectRatio": compute_aspect_ratio(w, h, "vertical"),
                    "hasAudio": is_vid,
                })
            if not media:
                return None
            return {
                "title": title,
                "caption": caption,
                "thumbnail": build_stream_url(thumb, "thumb.jpg", True) if thumb else media[0]["url"],
                "uploadDate": None,
                "audioUrl": media[0]["rawUrl"] if media[0]["type"] == "video" else None,
                "audioAvailable": any(m["type"] == "video" for m in media),
                "isCarousel": len(entries) > 1,
                "creator": {
                    "handle": uploader_id,
                    "name": uploader or uploader_id,
                    "avatarUrl": None,
                    "profileUrl": None,
                    "verified": False,
                },
                "media": media,
            }
    except Exception:
        return None


def extract_instagram(url: str, is_profile: bool, handle: Optional[str]) -> Dict[str, Any]:
    title = ""
    caption = ""
    thumbnail = None
    upload_date = None
    audio_url = None
    audio_available = False
    is_carousel = False
    creator = {
        "handle": handle,
        "name": None,
        "avatarUrl": None,
        "profileUrl": f"https://www.instagram.com/{handle}/" if handle else None,
        "verified": False,
    }
    media: List[Dict[str, Any]] = []

    if is_profile:
        path_parts = [p for p in urlparse(url).path.split("/") if p]
        target_handle = handle or (path_parts[0].lstrip("@") if path_parts else "instagram")
        embed_url = f"https://www.instagram.com/{target_handle}/embed/"
        try:
            resp = requests.get(embed_url, headers={"User-Agent": INSTAGRAM_EMBED_UA}, timeout=9)
            if resp.ok:
                html = resp.text
                ctx_match = re.search(r'"contextJSON"\s*:\s*"((?:\\.|[^"\\])*)"', html)
                if ctx_match:
                    unescaped = json.loads(f'"{ctx_match.group(1)}"')
                    ctx_obj = json.loads(unescaped)
                    ctx = ctx_obj.get("context") or {}
                    pic_url = ctx.get("profile_pic_url")
                    creator["handle"] = ctx.get("username") or target_handle
                    creator["name"] = ctx.get("full_name") or creator["handle"]
                    creator["verified"] = bool(ctx.get("is_verified") or ctx.get("verified"))
                    creator["profileUrl"] = f"https://www.instagram.com/{creator['handle']}/"
                    title = f"{creator['name']} (@{creator['handle']})"
                    followers = ctx.get("followers_count")
                    posts_cnt = ctx.get("posts_count")
                    if followers is not None or posts_cnt is not None:
                        caption = f"{followers or 0:,} followers · {posts_cnt or 0:,} public posts"
                    if pic_url:
                        proxied = build_stream_url(pic_url, f"{creator['handle']}-profile-hd.jpg", True)
                        creator["avatarUrl"] = proxied
                        thumbnail = proxied
                        media.append({
                            "url": proxied,
                            "rawUrl": pic_url,
                            "downloadUrl": build_stream_url(pic_url, f"{creator['handle']}-profile-photo-hd.jpg", False),
                            "thumbnail": proxied,
                            "type": "profile",
                            "quality": "Original HD · 1080×1080",
                            "format": "jpg",
                            "width": 1080,
                            "height": 1080,
                            "aspectRatio": "square",
                            "hasAudio": False,
                        })
        except Exception:
            pass
        return {
            "title": title or f"@{target_handle}",
            "caption": caption,
            "thumbnail": thumbnail,
            "uploadDate": upload_date,
            "audioUrl": audio_url,
            "audioAvailable": audio_available,
            "isCarousel": False,
            "creator": creator,
            "media": media,
        }

    sc_match = re.search(r"/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url, re.I)
    shortcode = sc_match.group(1) if sc_match else None
    is_reel = bool(re.search(r"/reels?/", url, re.I))

    if shortcode:
        embed_url = f"https://www.instagram.com/p/{shortcode}/embed/captioned/"
        try:
            resp = requests.get(embed_url, headers={"User-Agent": INSTAGRAM_EMBED_UA}, timeout=9)
            if resp.ok:
                html = resp.text
                soup = BeautifulSoup(html, "html.parser")

                user_el = soup.select_one(".UsernameText, a.eb_header_username")
                if user_el and user_el.get_text(strip=True):
                    creator["handle"] = user_el.get_text(strip=True).lstrip("@")
                    creator["name"] = creator["handle"]
                    creator["profileUrl"] = f"https://www.instagram.com/{creator['handle']}/"

                avatar_el = soup.select_one(".Header .Avatar img, a.Avatar img")
                if avatar_el and avatar_el.get("src"):
                    raw_av = str(avatar_el["src"]).replace("&amp;", "&")
                    creator["avatarUrl"] = build_stream_url(raw_av, f"{creator['handle'] or 'ig'}-avatar.jpg", True)

                cap_el = soup.select_one(".Caption")
                if cap_el:
                    for rm in cap_el.select(".CaptionUsername, .CaptionComments"):
                        rm.decompose()
                    cap_text = cap_el.get_text(" ", strip=True)
                    if cap_text:
                        caption = cap_text
                        title = cap_text[:90]

                ctx_match = re.search(r'"contextJSON"\s*:\s*"((?:\\.|[^"\\])*)"', html)
                media_data = None
                if ctx_match:
                    unescaped = json.loads(f'"{ctx_match.group(1)}"')
                    parsed_ctx = json.loads(unescaped)
                    media_data = (parsed_ctx.get("gql_data") or {}).get("shortcode_media")

                if media_data:
                    owner = media_data.get("owner") or {}
                    if owner.get("username"):
                        creator["handle"] = owner["username"]
                        creator["name"] = owner.get("full_name") or owner["username"]
                        creator["verified"] = bool(owner.get("is_verified"))
                        creator["profileUrl"] = f"https://www.instagram.com/{creator['handle']}/"
                    if owner.get("profile_pic_url"):
                        creator["avatarUrl"] = build_stream_url(
                            owner["profile_pic_url"], f"{creator['handle'] or 'ig'}-avatar.jpg", True
                        )

                    edges_cap = (media_data.get("edge_media_to_caption") or {}).get("edges") or []
                    if edges_cap and edges_cap[0].get("node", {}).get("text"):
                        caption = edges_cap[0]["node"]["text"]
                        title = caption.split("\n")[0][:95] or "Instagram Post"

                    sidecar = (media_data.get("edge_sidecar_to_children") or {}).get("edges") or []
                    if sidecar:
                        is_carousel = len(sidecar) > 1
                        for idx, edge in enumerate(sidecar):
                            node = edge.get("node") or {}
                            dims = node.get("dimensions") or {}
                            w = dims.get("width") or 1080
                            h = dims.get("height") or 1080
                            disp = node.get("display_url")
                            thumb = build_stream_url(disp, f"thumb-{idx+1}.jpg", True) if disp else None
                            if node.get("is_video") and node.get("video_url"):
                                raw_v = node["video_url"]
                                media.append({
                                    "url": build_stream_url(raw_v, f"slide-{idx+1}.mp4", True),
                                    "rawUrl": raw_v,
                                    "downloadUrl": build_stream_url(raw_v, safe_filename(f"{title or 'instagram'}-slide-{idx+1}", "mp4"), False),
                                    "thumbnail": thumb,
                                    "type": "video",
                                    "quality": f"Slide {idx+1} · 1080p Video",
                                    "format": "mp4",
                                    "width": w,
                                    "height": h,
                                    "aspectRatio": compute_aspect_ratio(w, h, "vertical"),
                                    "hasAudio": True,
                                })
                                audio_available = True
                                if not audio_url:
                                    audio_url = raw_v
                            elif disp:
                                media.append({
                                    "url": thumb,
                                    "rawUrl": disp,
                                    "downloadUrl": build_stream_url(disp, safe_filename(f"{title or 'instagram'}-slide-{idx+1}", "jpg"), False),
                                    "thumbnail": thumb,
                                    "type": "image",
                                    "quality": f"Slide {idx+1} · Original HD",
                                    "format": "jpg",
                                    "width": w,
                                    "height": h,
                                    "aspectRatio": compute_aspect_ratio(w, h, "square"),
                                    "hasAudio": False,
                                })
                    elif media_data.get("is_video") and media_data.get("video_url"):
                        raw_v = media_data["video_url"]
                        disp = media_data.get("display_url")
                        dims = media_data.get("dimensions") or {}
                        w = dims.get("width") or 1080
                        h = dims.get("height") or 1920
                        thumbnail = build_stream_url(disp, "thumb.jpg", True) if disp else None
                        media.append({
                            "url": build_stream_url(raw_v, safe_filename(title or "instagram-reel", "mp4"), True),
                            "rawUrl": raw_v,
                            "downloadUrl": build_stream_url(raw_v, safe_filename(title or "instagram-reel", "mp4"), False),
                            "thumbnail": thumbnail,
                            "type": "video",
                            "quality": "Full HD · 1080p",
                            "format": "mp4",
                            "width": w,
                            "height": h,
                            "aspectRatio": compute_aspect_ratio(w, h, "vertical" if is_reel else "square"),
                            "hasAudio": True,
                        })
                        audio_available = True
                        audio_url = raw_v
                    elif media_data.get("display_url"):
                        disp = media_data["display_url"]
                        dims = media_data.get("dimensions") or {}
                        w = dims.get("width") or 1080
                        h = dims.get("height") or 1080
                        proxied = build_stream_url(disp, "image.jpg", True)
                        thumbnail = proxied
                        media.append({
                            "url": proxied,
                            "rawUrl": disp,
                            "downloadUrl": build_stream_url(disp, safe_filename(title or "instagram-image", "jpg"), False),
                            "thumbnail": proxied,
                            "type": "image",
                            "quality": "Original HD · 1080p",
                            "format": "jpg",
                            "width": w,
                            "height": h,
                            "aspectRatio": compute_aspect_ratio(w, h, "square"),
                            "hasAudio": False,
                        })

                if not media:
                    img_el = soup.select_one("img.EmbeddedMediaImage")
                    if img_el:
                        srcset = str(img_el.get("srcset") or "")
                        best_img = parse_srcset_best(srcset) or str(img_el.get("src") or "").replace("&amp;", "&")
                        if best_img:
                            proxied = build_stream_url(best_img, "image.jpg", True)
                            thumbnail = proxied
                            media.append({
                                "url": proxied,
                                "rawUrl": best_img,
                                "downloadUrl": build_stream_url(best_img, safe_filename(title or "instagram-post", "jpg"), False),
                                "thumbnail": proxied,
                                "type": "image",
                                "quality": "Original HD · 1080p",
                                "format": "jpg",
                                "width": 1080,
                                "height": 1080,
                                "aspectRatio": "square",
                                "hasAudio": False,
                            })
        except Exception:
            pass

    if not media:
        ytdlp_res = extract_with_ytdlp_fallback(url)
        if ytdlp_res:
            return ytdlp_res

    return {
        "title": title or "Instagram Post",
        "caption": caption,
        "thumbnail": thumbnail or (media[0]["thumbnail"] if media else None),
        "uploadDate": upload_date,
        "audioUrl": audio_url,
        "audioAvailable": audio_available,
        "isCarousel": is_carousel,
        "creator": creator,
        "media": media,
    }


# ============================================================================
# TIKTOK: SHORTLINK UNSHORTENER + TIKWM PUBLIC API MIRROR
# ============================================================================

# Mobile UA used for every TikTok shortlink hop (vt./vm./ /t/ links).
TIKTOK_SHORTLINK_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X)"
TIKWM_BASE = os.environ.get("TIKWM_BASE", "https://www.tikwm.com").rstrip("/")
TIKTOK_CONTENT_PATH = re.compile(r"^/@[^/]+/(?:video|photo|story)/\d+", re.I)


def is_tiktok_shortlink(url: str) -> bool:
    p = urlparse(url)
    host = (p.hostname or "").lower()
    return host in {"vt.tiktok.com", "vm.tiktok.com"} or (
        host.endswith("tiktok.com") and p.path.startswith("/t/")
    )


def unshorten_tiktok(raw_url: str) -> str:
    """
    Fully unshortens vt.tiktok.com/ZS..., vm.tiktok.com/... and tiktok.com/t/... by following the
    redirect chain by hand with a mobile User-Agent, returning the canonical
    https://www.tiktok.com/@user/(video|photo|story)/<id> URL. If the chain ends in a geo / consent /
    login trap (/about, /login, "/") the last useful URL is returned instead of the trap.
    """
    current = raw_url.strip()
    best = current
    session = requests.Session()
    headers = {
        "User-Agent": TIKTOK_SHORTLINK_UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }

    for _ in range(8):
        p = urlparse(current)
        if TIKTOK_CONTENT_PATH.match(p.path):
            best = current
            break
        if not (p.hostname or "").lower().endswith("tiktok.com"):
            break
        try:
            resp = session.get(current, headers=headers, allow_redirects=False, timeout=8)
        except Exception:
            break

        location = resp.headers.get("Location")
        if location and resp.status_code in {301, 302, 303, 307, 308}:
            nxt = urljoin(current, location)
            np_ = urlparse(nxt)
            if re.search(r"/(?:about|login)(?:/|$)", np_.path, re.I) or np_.path in {"", "/"}:
                break
            current = nxt
            best = current
            continue

        if resp.status_code == 200:
            html = resp.text[:60000]
            found = (
                (re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']', html, re.I) or [None, None])[1]
                or (re.search(r'<meta[^>]+property=["\']og:url["\'][^>]+content=["\']([^"\']+)["\']', html, re.I) or [None, None])[1]
                or (re.search(r'https?://(?:www\.|m\.)?tiktok\.com/@[^"\'\s<>\\]+/(?:video|photo|story)/\d+', html, re.I) or [None])[0]
            )
            if found:
                best = found.replace("&amp;", "&")
        break

    p = urlparse(best)
    if TIKTOK_CONTENT_PATH.match(p.path):
        return urlunparse((p.scheme, p.netloc, p.path, "", "", ""))
    return best


def _abs_tikwm(u: Any) -> Optional[str]:
    if not isinstance(u, str) or not u:
        return None
    if re.match(r"^https?://", u, re.I):
        return u
    if u.startswith("//"):
        return f"https:{u}"
    return f"{TIKWM_BASE}{'' if u.startswith('/') else '/'}{u}"


def _tikwm_has_media(d: Any) -> bool:
    return bool(isinstance(d, dict) and (d.get("play") or d.get("hdplay") or d.get("images")))


def call_tikwm(video_url: str) -> Optional[Dict[str, Any]]:
    """
    GET https://www.tikwm.com/api/?url={url}  (POST form fallback). TikWM's free tier allows
    ~1 request/second, so one rate-limited response is retried after a short pause.
    """
    for _ in range(2):
        rate_limited = False
        try:
            r = requests.get(
                f"{TIKWM_BASE}/api/",
                params={"url": video_url, "hd": "1"},
                headers={"User-Agent": TIKTOK_SHORTLINK_UA, "Accept": "application/json, text/javascript, */*; q=0.01"},
                timeout=10,
            )
            if r.ok:
                j = r.json()
                if _tikwm_has_media(j.get("data")):
                    return j["data"]
                if re.search(r"limit", str(j.get("msg") or ""), re.I):
                    rate_limited = True
        except Exception:
            pass

        try:
            r = requests.post(
                f"{TIKWM_BASE}/api/",
                data={"url": video_url, "hd": "1"},
                headers={
                    "User-Agent": DESKTOP_UA,
                    "Accept": "application/json, text/javascript, */*; q=0.01",
                    "Origin": TIKWM_BASE,
                    "Referer": f"{TIKWM_BASE}/",
                },
                timeout=10,
            )
            if r.ok:
                j = r.json()
                if _tikwm_has_media(j.get("data")):
                    return j["data"]
                if re.search(r"limit", str(j.get("msg") or ""), re.I):
                    rate_limited = True
        except Exception:
            pass

        if not rate_limited:
            break
        time.sleep(1.3)
    return None


def extract_tiktok_via_tikwm(canonical_url: str, original_url: str) -> Optional[Dict[str, Any]]:
    """
    Dedicated TikTok post / Story / slideshow extractor built on TikWM.
      - data.images present -> mediaType "slideshow" (one image item per slide; audio exposed separately)
      - else data.play      -> mediaType "video"     (watermark-free MP4, plus HD when different)
    """
    d = None
    for candidate in dict.fromkeys([u for u in (canonical_url, original_url) if u]):
        d = call_tikwm(candidate)
        if d:
            break
    if not d:
        return None

    is_story = bool(re.search(r"/story/", canonical_url, re.I)) or bool(d.get("is_story"))
    images = [i for i in (d.get("images") or []) if i]
    is_slideshow = len(images) > 0
    title = d.get("title") or ("TikTok Story" if is_story else "TikTok Slideshow" if is_slideshow else "TikTok Post")

    author = d.get("author") or {}
    handle = author.get("unique_id")
    creator = {
        "handle": handle,
        "name": author.get("nickname") or handle,
        "avatarUrl": None,
        "profileUrl": f"https://www.tiktok.com/@{handle}" if handle else None,
        "verified": False,
    }
    raw_avatar = _abs_tikwm(author.get("avatar"))
    if raw_avatar:
        creator["avatarUrl"] = build_stream_url(raw_avatar, f"{handle or 'creator'}-avatar.jpg", True)

    raw_cover = _abs_tikwm(d.get("origin_cover") or d.get("cover"))
    thumbnail = build_stream_url(raw_cover, "thumbnail.jpg", True) if raw_cover else None

    music = d.get("music")
    raw_music = _abs_tikwm(music if isinstance(music, str) else (d.get("music_info") or {}).get("play"))
    media: List[Dict[str, Any]] = []

    if is_slideshow:
        for idx, img in enumerate(images):
            full = _abs_tikwm(img)
            if not full:
                continue
            preview = build_stream_url(full, f"slide-{idx+1}.jpg", True)
            media.append({
                "url": preview,
                "rawUrl": full,
                "downloadUrl": build_stream_url(full, safe_filename(f"{title}-slide-{idx+1}", "jpg"), False),
                "thumbnail": preview,
                "type": "image",
                "quality": f"Slide {idx+1} · Full HD",
                "format": "jpg",
                "width": 1080,
                "height": 1440,
                "aspectRatio": "vertical",
                "hasAudio": False,
            })
    else:
        sd = _abs_tikwm(d.get("play"))
        hd = _abs_tikwm(d.get("hdplay"))
        w = int(d.get("width") or 1080)
        h = int(d.get("height") or 1920)
        ar = compute_aspect_ratio(w, h, "vertical")

        def push(raw: str, quality: str, suffix: str) -> None:
            media.append({
                "url": build_stream_url(raw, safe_filename(title, "mp4"), True),
                "rawUrl": raw,
                "downloadUrl": build_stream_url(raw, safe_filename(f"{title}-{suffix}", "mp4"), False),
                "thumbnail": thumbnail,
                "type": "video",
                "quality": quality,
                "format": "mp4",
                "width": w,
                "height": h,
                "aspectRatio": ar,
                "hasAudio": True,
            })

        if sd:
            push(sd, "Clean Story Video (Watermark-Free) · 1080p" if is_story else "Clean Video (Watermark-Free) · 1080p", "watermark-free")
        if hd and hd != sd:
            push(hd, "Full HD · 1080p", "hd-1080p")

    if not media:
        return None
    if not thumbnail:
        thumbnail = media[0].get("thumbnail") or media[0].get("url")

    upload_date = None
    if d.get("create_time"):
        upload_date = time.strftime("%Y-%m-%d", time.gmtime(int(d["create_time"])))

    return {
        "title": title,
        "caption": d.get("title") or "",
        "thumbnail": thumbnail,
        "uploadDate": upload_date,
        "audioUrl": raw_music,
        "audioAvailable": bool(raw_music) or not is_slideshow,
        "isCarousel": is_slideshow and len(media) > 1,
        "mediaType": "slideshow" if is_slideshow else "video",
        "creator": creator,
        "media": media,
    }


# ============================================================================
# INSTAGRAM STORIES & HIGHLIGHTS: multi-stage public pipeline (never scrapes the login-gated HTML)
#   Stage 1  anonymous GraphQL / reels_media + public /embed/ pages
#   Stage 2  public story-downloader mirrors (POST the story/highlight URL, parse the media list)
# ============================================================================

IG_APP_ID = "936619743392459"
IG_GRAPHQL_HASHES = [
    h.strip()
    for h in os.environ.get("IG_GRAPHQL_HASHES", "452461e2dc7e6744e242663777b9d502").split(",")
    if h.strip()
]


def parse_story_target(raw_url: str) -> Optional[Dict[str, Any]]:
    """
    Parses /stories/<user>/<id>/, /stories/highlights/<id>/ and Base64 mobile-share links
    (/s/aGlnaGxpZ2h0OjE4MTQ0... -> "highlight:18144533410375920").
    """
    parsed = urlparse(decode_instagram_share_highlight(raw_url))
    parts = [p for p in parsed.path.split("/") if p]
    raw_sm = parse_qs(parsed.query).get("story_media_id", [None])[0]  # "<mediaId>_<userId>"
    sm_media, sm_user = (raw_sm.split("_", 1) + [None])[:2] if raw_sm else (None, None)

    if len(parts) >= 3 and parts[0] == "stories" and parts[1] == "highlights" and parts[2].isdigit():
        return {
            "kind": "highlight",
            "highlightId": parts[2],
            "username": None,
            "storyId": None,
            "storyMediaId": sm_media,
            "userId": sm_user,
            "canonicalUrl": f"https://www.instagram.com/stories/highlights/{parts[2]}/",
        }
    if len(parts) >= 2 and parts[0] == "stories" and parts[1] != "highlights":
        story_id = parts[2] if len(parts) > 2 and parts[2].isdigit() else sm_media
        return {
            "kind": "story",
            "highlightId": None,
            "username": parts[1],
            "storyId": story_id,
            "storyMediaId": sm_media,
            "userId": sm_user,
            "canonicalUrl": f"https://www.instagram.com/stories/{parts[1]}/{story_id + '/' if story_id else ''}",
        }
    return None


_PLACEHOLDER_RE = re.compile(
    r"instagram[_-]?logo|brand[_-]?assets|favicon|apple-touch-icon|/static/|/assets/(?:img|images|icons?)/|"
    r"/(?:logo|icons?)/|sprite|placeholder|loading\.",
    re.I,
)


def is_placeholder_asset(url: Optional[str]) -> bool:
    """Placeholder / chrome graphics that must never be presented as story media."""
    if not url or not re.match(r"^https?://", url, re.I):
        return True
    lower = url.lower()
    return (
        is_generic_instagram_logo(url)
        or bool(re.search(r"\.(?:svg|ico|gif)(?:[?#]|$)", lower))
        or bool(_PLACEHOLDER_RE.search(lower))
    )


def decode_escaped_url(raw: str) -> str:
    return (
        raw.replace("\\u0026", "&").replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")
    )


def _best_image_url(node: Dict[str, Any]) -> Optional[str]:
    cands = (node.get("image_versions2") or {}).get("candidates") or [
        {"url": r.get("src"), "width": r.get("config_width")} for r in (node.get("display_resources") or [])
    ]
    cands = sorted([c for c in cands if c.get("url")], key=lambda c: c.get("width") or 0, reverse=True)
    return (cands[0]["url"] if cands else None) or node.get("display_url")


def _reel_to_fetch(engine: str, reel: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    raw_items = reel.get("items") or [
        (e or {}).get("node") for e in ((reel.get("edge_highlight_reel_to_media") or {}).get("edges") or [])
    ]
    items: List[Dict[str, Any]] = []
    for node in raw_items:
        if not isinstance(node, dict):
            continue
        vids = node.get("video_resources") or node.get("video_versions") or []
        raw_vid = (vids[0].get("src") or vids[0].get("url")) if vids else node.get("video_url")
        raw_img = _best_image_url(node)
        is_vid = bool(raw_vid) and bool(node.get("is_video") or vids or node.get("video_url"))
        media_url = raw_vid if is_vid else raw_img
        if not media_url or is_placeholder_asset(media_url):
            continue
        ts = node.get("taken_at_timestamp") or node.get("taken_at")
        items.append({
            "type": "video" if is_vid else "photo",
            "url": media_url,
            "thumbnail": raw_img if raw_img and not is_placeholder_asset(raw_img) else None,
            "duration": float(node["video_duration"]) if node.get("video_duration") else None,
            "takenAt": time.strftime("%Y-%m-%d", time.gmtime(int(ts))) if ts else None,
        })
    if not items:
        return None

    u = reel.get("user") or reel.get("owner") or {}
    cover_raw = ((reel.get("cover_media") or {}).get("cropped_image_version") or {}).get("url")
    creator = None
    if u:
        creator = {
            "handle": u.get("username"),
            "name": u.get("full_name") or u.get("username"),
            "verified": bool(u.get("is_verified")),
            "avatarUrl": u.get("profile_pic_url"),
            "profileUrl": f"https://www.instagram.com/{u['username']}/" if u.get("username") else None,
        }
    return {
        "engine": engine,
        "items": items,
        "title": reel.get("title") or None,
        "cover": cover_raw if cover_raw and not is_placeholder_asset(cover_raw) else None,
        "creator": creator,
    }


def ig_stage_graphql(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Stage 1a: anonymous GraphQL reel query + v1 reels_media."""
    headers = {
        "User-Agent": INSTAGRAM_EMBED_UA,
        "x-ig-app-id": IG_APP_ID,
        "Accept": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": "https://www.instagram.com/",
    }

    def get_json(url: str, params: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
        try:
            r = requests.get(url, params=params, headers=headers, timeout=8)
            return r.json() if r.ok else None
        except Exception:
            return None

    reel_id = f"highlight:{t['highlightId']}" if t.get("highlightId") else t.get("userId")
    variables = {
        "reel_ids": [t["userId"]] if t.get("userId") else [],
        "tag_names": [],
        "location_ids": [],
        "highlight_reel_ids": [t["highlightId"]] if t.get("highlightId") else [],
        "precomposed_overlay": False,
        "show_story_viewer_list": False,
    }
    if variables["reel_ids"] or variables["highlight_reel_ids"]:
        for h in IG_GRAPHQL_HASHES:
            j = get_json(
                "https://www.instagram.com/graphql/query/",
                {"query_hash": h, "variables": json.dumps(variables)},
            )
            data = (j or {}).get("data") or {}
            reel = (
                ((data.get("reels_media") or [None])[0])
                or (data.get("user") or {}).get("reel")
                or data.get("highlight_reel")
            )
            out = _reel_to_fetch("graphql", reel) if reel else None
            if out:
                return out

    if reel_id:
        j = get_json("https://i.instagram.com/api/v1/feed/reels_media/", {"reel_ids": reel_id}) or {}
        reel = (j.get("reels") or {}).get(reel_id) or ((j.get("reels_media") or [None])[0])
        out = _reel_to_fetch("reels_media", reel) if reel else None
        if out:
            return out
    return None


def ig_stage_embed(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Stage 1b: public /embed/ page for the story's media shortcode (login shell is detected and skipped)."""
    shortcodes = list(dict.fromkeys(
        sc for sc in (id_to_shortcode(t.get("storyId")), id_to_shortcode(t.get("storyMediaId"))) if sc
    ))
    candidates = [
        u for sc in shortcodes
        for u in (f"https://www.instagram.com/p/{sc}/embed/captioned/", f"https://www.instagram.com/p/{sc}/embed/")
    ]
    for cand in candidates:
        try:
            r = requests.get(
                cand,
                headers={
                    "User-Agent": INSTAGRAM_EMBED_UA,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
                timeout=8,
            )
            if not r.ok:
                continue
            html = r.text
            soup = BeautifulSoup(html, "html.parser")
            og_i = soup.find("meta", property="og:image")
            og_v = soup.find("meta", property="og:video") or soup.find("meta", property="og:video:secure_url")
            og_image = og_i.get("content") if og_i else None
            og_video = og_v.get("content") if og_v else None
            if '"LoginAndSignupPage"' in html or (
                not og_video and ".mp4" not in html and (not og_image or is_placeholder_asset(og_image))
            ):
                continue

            video = None
            mp4_idx = html.find(".mp4")
            if mp4_idx != -1:
                start = html.rfind("https:", 0, mp4_idx)
                end = html.find('"', mp4_idx)
                if start != -1 and end > start:
                    video = decode_escaped_url(html[start:end])
            if not video and og_video:
                video = decode_escaped_url(str(og_video))
            if video and is_placeholder_asset(video):
                video = None

            image = None
            emb = soup.find("img", class_="EmbeddedMediaImage")
            if emb and emb.get("srcset"):
                best, best_w = None, -1
                for part in str(emb["srcset"]).split(","):
                    toks = part.strip().split()
                    if not toks:
                        continue
                    m = re.match(r"^(\d+)w$", toks[1]) if len(toks) > 1 else None
                    w = int(m.group(1)) if m else 0
                    if w >= best_w:
                        best, best_w = decode_escaped_url(toks[0]), w
                image = best
            if not image and emb and emb.get("src"):
                image = decode_escaped_url(str(emb["src"]))
            if not image and og_image:
                image = decode_escaped_url(str(og_image))
            if not image:
                dm = re.search(r'"display_url":\s*"([^"]+)"', html)
                image = decode_escaped_url(dm.group(1)) if dm else None
            if image and is_placeholder_asset(image):
                image = None

            media_url = video or image
            if not media_url:
                continue

            uel = soup.find(class_="Username")
            user = ""
            if uel:
                toks = uel.get_text(strip=True).split()
                user = re.sub(r"Verified.*$", "", toks[0], flags=re.I) if toks else ""
            return {
                "engine": "embed",
                "items": [{
                    "type": "video" if video else "photo",
                    "url": media_url,
                    "thumbnail": image,
                    "duration": None,
                    "takenAt": None,
                }],
                "cover": image,
                "creator": {
                    "handle": user,
                    "name": user,
                    "profileUrl": f"https://www.instagram.com/{user}/",
                    "verified": False,
                } if user else None,
            }
        except Exception:
            continue
    return None


# ---- Stage 2: public mirrors -------------------------------------------------

# Default public story-downloader mirrors. These third-party sites change their endpoints and
# anti-bot tokens often; override or extend the list without touching code by setting
# IG_MIRROR_ENDPOINTS to a JSON array of objects with the same keys.
DEFAULT_IG_MIRRORS: List[Dict[str, Any]] = [
    {"name": "sssinstagram", "endpoint": "https://sssinstagram.com/api/convert", "encoding": "json",
     "urlField": "target_url", "referer": "https://sssinstagram.com/"},
    {"name": "indown", "endpoint": "https://indown.io/download", "encoding": "form", "urlField": "link",
     "tokenPage": "https://indown.io/", "referer": "https://indown.io/"},
    {"name": "snapinsta", "endpoint": "https://snapinsta.app/action2.php", "encoding": "form", "urlField": "url",
     "fields": {"action": "post", "lang": "en"}, "tokenPage": "https://snapinsta.app/",
     "referer": "https://snapinsta.app/"},
    {"name": "fastdl", "endpoint": "https://fastdl.app/api/convert", "encoding": "json", "urlField": "url",
     "referer": "https://fastdl.app/"},
]


def load_mirror_configs() -> List[Dict[str, Any]]:
    raw = os.environ.get("IG_MIRROR_ENDPOINTS")
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list) and parsed:
                return parsed
        except Exception:
            pass
    return DEFAULT_IG_MIRRORS


_MIRROR_VIDEO_HINT = re.compile(r"\.mp4(?:[?#]|$)|video|\bmp4\b", re.I)
_MIRROR_IMAGE_HINT = re.compile(r"\.(?:jpe?g|webp|png|heic)(?:[?#]|$)|photo|image|\bjpe?g\b", re.I)
_MIRROR_THUMB_KEY = re.compile(r"thumb|cover|poster|preview|avatar|profile|logo|icon", re.I)


def guess_mirror_type(hay: str) -> Optional[str]:
    """Explicit file extensions win over loose words like "video"/"photo"."""
    if re.search(r"\.mp4(?:[?#\s]|$)", hay, re.I):
        return "video"
    if re.search(r"\.(?:jpe?g|webp|png|heic)(?:[?#\s]|$)", hay, re.I):
        return "photo"
    if _MIRROR_VIDEO_HINT.search(hay):
        return "video"
    if _MIRROR_IMAGE_HINT.search(hay):
        return "photo"
    return None


def extract_mirror_links(body: str, base_url: str) -> List[Dict[str, Any]]:
    """Pulls candidate media links out of whatever a mirror returned (JSON, JSON-wrapped HTML, or HTML)."""
    out: List[Dict[str, Any]] = []

    def absu(u: str) -> Optional[str]:
        try:
            return urljoin(base_url, decode_escaped_url(u.strip()))
        except Exception:
            return None

    def from_html(html: str) -> None:
        soup = BeautifulSoup(html, "html.parser")
        for el in soup.select("a[href], video[src], video source[src]"):
            href = el.get("href") or el.get("src")
            url = absu(str(href)) if href else None
            if not url:
                continue
            text = " ".join([
                el.get_text(" ", strip=True),
                str(el.get("download") or ""),
                " ".join(el.get("class") or []),
                str(el.get("title") or ""),
            ])
            is_a = el.name == "a"
            looks_like_download = (
                not is_a
                or el.has_attr("download")
                or bool(re.search(r"download|save|video|photo|image|\bhd\b", text, re.I))
                or bool(_MIRROR_VIDEO_HINT.search(url))
                or bool(_MIRROR_IMAGE_HINT.search(url))
                or bool(re.search(r"cdninstagram|fbcdn", url, re.I))
            )
            if not looks_like_download:
                continue
            scope = el.find_parent(["div", "li", "article", "section", "tr"])
            thumb_raw = None
            if scope:
                img = scope.find("img")
                vid = scope.find("video")
                thumb_raw = (img.get("src") if img else None) or (vid.get("poster") if vid else None)
            out.append({
                "url": url,
                "type": "video" if not is_a else guess_mirror_type(f"{url} {text}"),
                "thumb": absu(str(thumb_raw)) if thumb_raw else None,
            })

    def walk(node: Any, key: str = "") -> None:
        if isinstance(node, str):
            if re.search(r"<(?:a|video|source)\b", node, re.I):
                from_html(node)
            elif re.match(r"^https?://", node, re.I) and not _MIRROR_THUMB_KEY.search(key):
                url = absu(node)
                if url and (
                    _MIRROR_VIDEO_HINT.search(url) or _MIRROR_IMAGE_HINT.search(url)
                    or re.search(r"cdninstagram|fbcdn|download|/get\?", url, re.I)
                ):
                    out.append({"url": url, "type": guess_mirror_type(f"{url} {key}"), "thumb": None})
        elif isinstance(node, list):
            for n in node:
                walk(n, key)
        elif isinstance(node, dict):
            thumb_key = next((k for k, v in node.items() if _MIRROR_THUMB_KEY.search(k) and isinstance(v, str)), None)
            before = len(out)
            for k, v in node.items():
                walk(v, k)
            if thumb_key:
                thumb = absu(node[thumb_key])
                for i in range(before, len(out)):
                    if not out[i].get("thumb"):
                        out[i]["thumb"] = thumb

    trimmed = body.strip()
    if trimmed.startswith("{") or trimmed.startswith("["):
        try:
            walk(json.loads(trimmed))
        except Exception:
            from_html(body)
    else:
        from_html(body)
    return out


def probe_media_type(url: str) -> Optional[str]:
    """Resolves a mirror link whose type is unknown by asking the server for the first byte."""
    try:
        r = requests.get(url, headers={"User-Agent": DESKTOP_UA, "Range": "bytes=0-0"}, stream=True, timeout=6)
        ct = (r.headers.get("content-type") or "").lower()
        r.close()
        if ct.startswith("video/"):
            return "video"
        if ct.startswith("image/"):
            return "photo"
    except Exception:
        pass
    return None


def run_mirror(cfg: Dict[str, Any], target_url: str) -> List[Dict[str, Any]]:
    fields: Dict[str, str] = dict(cfg.get("fields") or {})
    headers = {
        "User-Agent": DESKTOP_UA,
        "Accept": "application/json, text/html, */*;q=0.8",
        "X-Requested-With": "XMLHttpRequest",
    }
    if cfg.get("referer"):
        headers["Referer"] = cfg["referer"]
        p = urlparse(cfg["referer"])
        headers["Origin"] = f"{p.scheme}://{p.netloc}"

    session = requests.Session()
    if cfg.get("tokenPage"):
        try:
            page = session.get(cfg["tokenPage"], headers={"User-Agent": DESKTOP_UA}, timeout=8)
            soup = BeautifulSoup(page.text, "html.parser")
            for inp in soup.select("form input[type=hidden][name]"):
                name, value = inp.get("name"), inp.get("value")
                if name and value is not None and name not in fields:
                    fields[str(name)] = str(value)
        except Exception:
            pass
    fields[cfg.get("urlField") or "url"] = target_url

    method = (cfg.get("method") or "POST").upper()
    if method == "GET":
        resp = session.get(cfg["endpoint"], params=fields, headers=headers, timeout=15)
    elif cfg.get("encoding") == "json":
        resp = session.post(cfg["endpoint"], json=fields, headers=headers, timeout=15)
    else:
        resp = session.post(cfg["endpoint"], data=fields, headers=headers, timeout=15)
    if not resp.ok:
        return []

    links = extract_mirror_links(resp.text, cfg["endpoint"])
    seen: set = set()
    items: List[Dict[str, Any]] = []
    for link in links:
        url = link["url"]
        if url in seen or is_placeholder_asset(url):
            continue
        # a thumbnail-only <img> that was picked up as a link must not become a story of its own
        if any(o is not link and o.get("thumb") == url for o in links):
            continue
        seen.add(url)
        typ = link.get("type") or probe_media_type(url)
        if not typ:
            continue
        thumb = link.get("thumb")
        items.append({
            "type": typ,
            "url": url,
            "thumbnail": thumb if thumb and not is_placeholder_asset(thumb) else (url if typ == "photo" else None),
            "duration": None,
            "takenAt": None,
        })
    return items


def ig_stage_mirrors(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Stage 2: try each public mirror in order until one returns real media."""
    for cfg in load_mirror_configs():
        try:
            items = run_mirror(cfg, t["canonicalUrl"])
            if items:
                return {"engine": f"mirror:{cfg.get('name', 'custom')}", "items": items}
        except Exception:
            continue
    return None


def fetch_instagram_story_media(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    for stage in (ig_stage_graphql, ig_stage_embed, ig_stage_mirrors):
        out = stage(t)
        if out and out.get("items"):
            return out
    return None


def extract_tiktok(url: str, is_profile: bool, handle: Optional[str]) -> Dict[str, Any]:
    title = ""
    caption = ""
    thumbnail = None
    upload_date = None
    audio_url = None
    audio_available = False
    is_carousel = False
    creator = {
        "handle": handle,
        "name": None,
        "avatarUrl": None,
        "profileUrl": f"https://www.tiktok.com/@{handle}" if handle else None,
        "verified": False,
    }
    media: List[Dict[str, Any]] = []

    if is_profile:
        target_handle = handle or (url.split("/@")[1].split("/")[0].split("?")[0] if "/@" in url else "tiktok")
        # Strategy 1: TikTok embed page scraper (bypasses Cloudflare & datacenter IP blocks, extracts 1080p DP)
        try:
            emb_resp = requests.get(
                f"https://www.tiktok.com/embed/@{target_handle}",
                headers={"User-Agent": DESKTOP_UA},
                timeout=8,
            )
            if emb_resp.ok:
                m = re.search(r'https://[^"\'\s]+(?:avt|avatar|tiktokcdn)[^"\'\s]+tplv-tiktokx-cropcenter:[^"\'\s]+', emb_resp.text, re.I)
                if m:
                    raw_av = m.group(0).replace("&amp;", "&")
                    hd_av = re.sub(r'cropcenter:\d+:\d+', 'cropcenter:1080:1080', raw_av)
                    creator["handle"] = target_handle
                    creator["name"] = target_handle
                    creator["profileUrl"] = f"https://www.tiktok.com/@{target_handle}"
                    title = f"{target_handle} (@{target_handle})"
                    proxied = build_stream_url(hd_av, f"{target_handle}-avatar.jpg", True)
                    creator["avatarUrl"] = proxied
                    thumbnail = proxied
                    media.append({
                        "url": proxied,
                        "rawUrl": hd_av,
                        "downloadUrl": build_stream_url(hd_av, f"{target_handle}-profile-photo-hd.jpg", False),
                        "thumbnail": proxied,
                        "type": "profile",
                        "quality": "Original HD · 1080×1080",
                        "format": "jpg",
                        "width": 1080,
                        "height": 1080,
                        "aspectRatio": "square",
                        "hasAudio": False,
                    })
        except Exception:
            pass

        if not media:
            try:
                resp = requests.get(
                    f"https://www.tikwm.com/api/user/info?unique_id={target_handle}",
                    headers={"User-Agent": DESKTOP_UA},
                    timeout=8,
                )
                if resp.ok:
                    user = (resp.json().get("data") or {}).get("user") or {}
                    hd_av = user.get("avatarLarger") or user.get("avatarMedium") or user.get("avatarThumb")
                    if hd_av:
                        creator["handle"] = user.get("uniqueId") or target_handle
                        creator["name"] = user.get("nickname") or creator["handle"]
                        creator["verified"] = bool(user.get("verified"))
                        creator["profileUrl"] = f"https://www.tiktok.com/@{creator['handle']}"
                        caption = user.get("signature") or ""
                        title = f"{creator['name']} (@{creator['handle']})"
                        proxied = build_stream_url(hd_av, f"{creator['handle']}-avatar.jpg", True)
                        creator["avatarUrl"] = proxied
                        thumbnail = proxied
                        media.append({
                            "url": proxied,
                            "rawUrl": hd_av,
                            "downloadUrl": build_stream_url(hd_av, f"{creator['handle']}-profile-photo-hd.jpg", False),
                            "thumbnail": proxied,
                            "type": "profile",
                            "quality": "Original HD · 1080×1080",
                            "format": "jpg",
                            "width": 1080,
                            "height": 1080,
                            "aspectRatio": "square",
                            "hasAudio": False,
                        })
            except Exception:
                pass
        return {
            "title": title or f"@{target_handle}",
            "caption": caption,
            "thumbnail": thumbnail,
            "uploadDate": upload_date,
            "audioUrl": audio_url,
            "audioAvailable": audio_available,
            "isCarousel": False,
            "creator": creator,
            "media": media,
        }

    # Strategy A: dedicated TikTok unshortener + TikWM public API (videos, Stories, slideshows)
    canonical = unshorten_tiktok(url)
    via_tikwm = extract_tiktok_via_tikwm(canonical, url)
    if via_tikwm:
        return via_tikwm
    url = canonical

    if not media:
        ytdlp_res = extract_with_ytdlp_fallback(url)
        if ytdlp_res:
            return ytdlp_res

    return {
        "title": title or "TikTok Post",
        "caption": caption,
        "thumbnail": thumbnail or (media[0]["thumbnail"] if media else None),
        "uploadDate": upload_date,
        "audioUrl": audio_url,
        "audioAvailable": audio_available,
        "isCarousel": is_carousel,
        "creator": creator,
        "media": media,
    }


def extract_pinterest(url: str, is_profile: bool, handle: Optional[str]) -> Dict[str, Any]:
    title = ""
    caption = ""
    thumbnail = None
    audio_url = None
    audio_available = False
    creator = {
        "handle": handle,
        "name": None,
        "avatarUrl": None,
        "profileUrl": f"https://www.pinterest.com/{handle}/" if handle else None,
        "verified": False,
    }
    media: List[Dict[str, Any]] = []

    try:
        oembed = requests.get(
            f"https://www.pinterest.com/oembed.json?url={url}",
            headers={"User-Agent": DESKTOP_UA},
            timeout=6,
        )
        if oembed.ok:
            data = oembed.json()
            title = data.get("title") or ""
            caption = title
            creator["name"] = data.get("author_name")
            creator["profileUrl"] = data.get("author_url")
            if data.get("thumbnail_url"):
                thumbnail = re.sub(r"/(?:\d{2,4}x(?:\d{2,4})?|[0-9]+x[0-9]+)/", "/originals/", data["thumbnail_url"])
    except Exception:
        pass

    try:
        resp = requests.get(url, headers={"User-Agent": DESKTOP_UA}, timeout=8)
        if resp.ok:
            html = resp.text
            soup = BeautifulSoup(html, "html.parser")
            og_title = soup.find("meta", property="og:title")
            og_desc = soup.find("meta", property="og:description")
            og_img = soup.find("meta", property="og:image")
            og_vid = soup.find("meta", property="og:video") or soup.find("meta", property="og:video:url")

            if not title and og_title and og_title.get("content"):
                title = str(og_title["content"])
            if not caption and og_desc and og_desc.get("content"):
                caption = str(og_desc["content"])

            vid_url = str(og_vid["content"]) if og_vid and og_vid.get("content") else None
            if not vid_url:
                v_match = re.search(r'"(https://v1\.pinimg\.com/videos/[^"]+\.mp4)"', html)
                if v_match:
                    vid_url = v_match.group(1)

            img_url = str(og_img["content"]) if og_img and og_img.get("content") else thumbnail
            if img_url and "pinimg.com" in img_url:
                img_url = re.sub(r"/(?:\d{2,4}x(?:\d{2,4})?|[0-9]+x[0-9]+)/", "/originals/", img_url)

            if is_profile and img_url:
                creator["avatarUrl"] = img_url
                thumbnail = img_url
                media.append({
                    "url": img_url,
                    "rawUrl": img_url,
                    "downloadUrl": build_stream_url(img_url, safe_filename(title or "pinterest-profile", "jpg"), False),
                    "thumbnail": img_url,
                    "type": "profile",
                    "quality": "Original HD · 1080×1080",
                    "format": "jpg",
                    "width": 1080,
                    "height": 1080,
                    "aspectRatio": "square",
                    "hasAudio": False,
                })
            else:
                if vid_url:
                    media.append({
                        "url": build_stream_url(vid_url, safe_filename(title or "pinterest-video", "mp4"), True),
                        "rawUrl": vid_url,
                        "downloadUrl": build_stream_url(vid_url, safe_filename(title or "pinterest-video", "mp4"), False),
                        "thumbnail": img_url,
                        "type": "video",
                        "quality": "Full HD Video",
                        "format": "mp4",
                        "width": 1080,
                        "height": 1920,
                        "aspectRatio": "vertical",
                        "hasAudio": True,
                    })
                    audio_available = True
                    audio_url = vid_url
                elif img_url:
                    media.append({
                        "url": img_url,
                        "rawUrl": img_url,
                        "downloadUrl": build_stream_url(img_url, safe_filename(title or "pinterest-pin", "jpg"), False),
                        "thumbnail": img_url,
                        "type": "image",
                        "quality": "Original Master HD",
                        "format": "jpg",
                        "width": 1200,
                        "height": 1800,
                        "aspectRatio": "vertical",
                        "hasAudio": False,
                    })
    except Exception:
        pass

    return {
        "title": title or "Pinterest Pin",
        "caption": caption,
        "thumbnail": thumbnail or (media[0]["thumbnail"] if media else None),
        "uploadDate": None,
        "audioUrl": audio_url,
        "audioAvailable": audio_available,
        "isCarousel": False,
        "creator": creator,
        "media": media,
    }


def extract_youtube(target_url: str, is_profile: bool, profile_handle: Optional[str]) -> Dict[str, Any]:
    title = ""
    caption = ""
    thumbnail = None
    upload_date = None
    audio_url = None
    audio_available = False
    creator = {
        "handle": profile_handle,
        "name": None,
        "avatarUrl": None,
        "profileUrl": f"https://www.youtube.com/@{profile_handle}" if profile_handle else None,
        "verified": False,
    }
    media: List[Dict[str, Any]] = []

    # 1. Profile / Channel Avatar Mode (DP)
    if is_profile:
        handle = profile_handle or (target_url.split("/@")[1].split("/")[0] if "/@" in target_url else "")
        try:
            resp = requests.get(
                target_url,
                headers={"User-Agent": DESKTOP_UA, "Accept-Language": "en-US,en;q=0.9"},
                timeout=8,
            )
            if resp.ok:
                html = resp.text
                og_title = re.search(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
                og_img = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
                og_desc = re.search(r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
                avatar_match = re.search(r'"avatar":\s*\{\s*"thumbnails":\s*\[(.*?)\]', html, re.S)

                raw_avatar = og_img.group(1) if og_img else None
                if avatar_match:
                    try:
                        thumbs = json.loads(f"[{avatar_match.group(1)}]")
                        if thumbs:
                            raw_avatar = thumbs[-1].get("url") or raw_avatar
                    except Exception:
                        pass

                if raw_avatar:
                    hd_avatar = re.sub(r"=s\d+", "=s1080", raw_avatar)
                    creator["name"] = og_title.group(1) if og_title else (handle or "YouTube Creator")
                    creator["handle"] = handle or None
                    creator["profileUrl"] = target_url
                    title = f"{creator['name']} (@{creator['handle']})" if creator["handle"] else creator["name"]
                    caption = og_desc.group(1) if og_desc else ""

                    proxied_avatar = build_stream_url(hd_avatar, f"{handle or 'creator'}-avatar-hd.jpg", True)
                    creator["avatarUrl"] = proxied_avatar
                    thumbnail = proxied_avatar

                    media.append({
                        "url": proxied_avatar,
                        "rawUrl": hd_avatar,
                        "downloadUrl": build_stream_url(hd_avatar, f"{handle or 'creator'}-profile-photo-hd.jpg", False),
                        "thumbnail": proxied_avatar,
                        "type": "profile",
                        "quality": "Original HD · 1080×1080",
                        "format": "jpg",
                        "width": 1080,
                        "height": 1080,
                        "aspectRatio": "square",
                        "hasAudio": False,
                    })
        except Exception:
            pass

    # 2. Video / Shorts Mode
    if not media:
        yt_bin = "/bin/yt-dlp" if os.path.exists("/bin/yt-dlp") else "yt-dlp"

        # Strategy A: Standard yt-dlp with full progressive/merged formats (up to 4K / 2160p)
        try:
            cmd = [yt_bin, "--dump-single-json", "--no-warnings", target_url]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            if proc.returncode == 0 and proc.stdout.strip():
                yt_data = json.loads(proc.stdout)
        except Exception:
            pass

        # Strategy B: Bot bypass fallback with android client
        if not yt_data:
            try:
                cmd = [
                    yt_bin,
                    "--dump-single-json",
                    "--no-warnings",
                    "--extractor-args",
                    "youtube:player_client=android",
                    target_url,
                ]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                if proc.returncode == 0 and proc.stdout.strip():
                    yt_data = json.loads(proc.stdout)
            except Exception:
                pass

        # Strategy C: Bot bypass fallback with android,web
        if not yt_data:
            try:
                cmd = [
                    yt_bin,
                    "--dump-single-json",
                    "--no-warnings",
                    "--extractor-args",
                    "youtube:player_client=android,web",
                    target_url,
                ]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                if proc.returncode == 0 and proc.stdout.strip():
                    yt_data = json.loads(proc.stdout)
            except Exception:
                pass

        # Strategy D: Invidious fallback
        if not yt_data:
            video_id = ""
            parsed = urlparse(target_url)
            qs = parse_qs(parsed.query)
            if qs.get("v"):
                video_id = qs["v"][0]
            elif "/shorts/" in parsed.path:
                video_id = parsed.path.split("/shorts/")[1].split("/")[0]

            if video_id:
                for mir in [
                    f"https://yt.drgnz.club/api/v1/videos/{video_id}",
                    f"https://invidious.jing.rocks/api/v1/videos/{video_id}",
                    f"https://invidious.projectsegfau.lt/api/v1/videos/{video_id}",
                ]:
                    try:
                        m_res = requests.get(mir, headers={"User-Agent": DESKTOP_UA}, timeout=6)
                        if m_res.ok:
                            yt_data = m_res.json()
                            break
                    except Exception:
                        pass

        if yt_data:
            title = yt_data.get("title") or "YouTube Video"
            caption = yt_data.get("description") or ""
            if yt_data.get("upload_date"):
                d = str(yt_data["upload_date"])
                upload_date = f"{d[:4]}-{d[4:6]}-{d[6:8]}"
            elif yt_data.get("published"):
                upload_date = time.strftime("%Y-%m-%d", time.gmtime(yt_data["published"]))

            creator["name"] = yt_data.get("uploader") or yt_data.get("channel") or yt_data.get("author") or "YouTube Creator"
            creator["handle"] = yt_data.get("uploader_id") or yt_data.get("channel_id")
            creator["profileUrl"] = yt_data.get("channel_url") or yt_data.get("uploader_url")

            raw_thumb = yt_data.get("thumbnail") or (f"https://i.ytimg.com/vi/{yt_data['id']}/maxresdefault.jpg" if yt_data.get("id") else None)
            if raw_thumb:
                thumbnail = build_stream_url(raw_thumb, "thumbnail.jpg", True)

            is_shorts = "/shorts/" in target_url or any(
                f.get("height") and f.get("width") and f["height"] > f["width"]
                for f in yt_data.get("formats", [])
            )
            default_aspect = "vertical" if is_shorts else "horizontal"

            raw_formats = yt_data.get("formats") or yt_data.get("formatStreams") or []
            heights_found = [f.get("height") or 0 for f in raw_formats if f.get("height")]
            max_height = max(heights_found) if heights_found else 1080

            progressive_format = next(
                (f for f in raw_formats if f.get("vcodec") and f["vcodec"] != "none" and f.get("acodec") and f["acodec"] != "none" and f.get("url") and "manifest.googlevideo.com" not in f["url"]),
                next((f for f in raw_formats if f.get("format_id") == "18" and f.get("url")), None)
            )
            preview_url = (progressive_format.get("url") if progressive_format else None) or next((f["url"] for f in raw_formats if f.get("url") and f.get("vcodec") != "none"), target_url)

            audio_available = True
            audio_url = target_url

            target_ladder = [2160, 1440, 1080, 720, 480, 360]
            valid_heights = [h for h in target_ladder if h <= max_height or h == 720 or h == 360]
            if max_height >= 1080 and 1080 not in valid_heights:
                valid_heights.append(1080)
            valid_heights.sort(reverse=True)

            for idx, h in enumerate(valid_heights):
                q_name = f"{h}p"
                if h >= 2160: q_name = "4K · 2160p"
                elif h >= 1440: q_name = "QHD · 1440p"
                elif h >= 1080: q_name = "Full HD · 1080p"
                elif h >= 720: q_name = "HD · 720p"
                elif h >= 480: q_name = "SD · 480p"
                else: q_name = "SD · 360p"

                w = (1215 if h == 2160 else 810 if h == 1440 else 608 if h == 1080 else 405 if h == 720 else 270) if is_shorts else (3840 if h == 2160 else 2560 if h == 1440 else 1920 if h == 1080 else 1280 if h == 720 else 854)

                media.append({
                    "url": build_stream_url(preview_url, safe_filename(f"{title}-{h}p", "mp4"), True),
                    "rawUrl": target_url,
                    "downloadUrl": f"/api/download?downloadId=pending&format=mp4&assetType=media&mediaIndex={idx}",
                    "thumbnail": thumbnail,
                    "type": "video",
                    "quality": q_name,
                    "format": "mp4",
                    "width": w,
                    "height": h,
                    "aspectRatio": compute_aspect_ratio(w, h, default_aspect),
                    "hasAudio": True,
                })

            if not media:
                avail = [f for f in raw_formats if f.get("url") and (f.get("vcodec") != "none" or f.get("height"))]
                avail.sort(key=lambda x: x.get("height") or 0, reverse=True)
                if avail:
                    top_f = avail[0]
                    h = top_f.get("height") or 720
                    w = top_f.get("width") or (720 if is_shorts else 1280)
                    media.append({
                        "url": build_stream_url(top_f["url"], safe_filename(title, "mp4"), True),
                        "rawUrl": top_f["url"],
                        "downloadUrl": build_stream_url(top_f["url"], safe_filename(title, "mp4"), False),
                        "thumbnail": thumbnail,
                        "type": "video",
                        "quality": "Full HD · 1080p" if h >= 1080 else "HD · 720p" if h >= 720 else "SD · 480p",
                        "format": top_f.get("ext") or "mp4",
                        "width": w,
                        "height": h,
                        "aspectRatio": compute_aspect_ratio(w, h, default_aspect),
                        "hasAudio": bool(top_f.get("acodec") and top_f["acodec"] != "none"),
                    })

    # oEmbed fallback
    if not media:
        try:
            oem = requests.get(f"https://www.youtube.com/oembed?url={requests.utils.quote(target_url)}&format=json", timeout=5).json()
            title = oem.get("title") or title or "YouTube Video"
            creator["name"] = oem.get("author_name") or creator["name"]
            raw_thumb = oem.get("thumbnail_url")
            if raw_thumb:
                thumbnail = build_stream_url(raw_thumb, "thumbnail.jpg", True)
            media.append({
                "url": build_stream_url(target_url, safe_filename(title, "mp4"), True),
                "rawUrl": target_url,
                "downloadUrl": build_stream_url(target_url, safe_filename(title, "mp4"), False),
                "thumbnail": thumbnail,
                "type": "video",
                "quality": "Full HD · 1080p",
                "format": "mp4",
                "width": 1920,
                "height": 1080,
                "aspectRatio": "horizontal",
                "hasAudio": True,
            })
            audio_available = True
            audio_url = target_url
        except Exception:
            pass

    return {
        "title": title or "YouTube Video",
        "caption": caption,
        "thumbnail": thumbnail,
        "uploadDate": upload_date,
        "audioUrl": audio_url,
        "audioAvailable": audio_available,
        "isCarousel": False,
        "creator": creator,
        "media": media,
    }


@app.get("/api/stream")
def stream_media(
    url: str = Query(...),
    filename: str = Query(default="omnidownloader-media"),
    inline: Optional[str] = Query(default=None),
):
    parsed = urlparse(url)
    referer = (
        "https://www.tiktok.com/"
        if "tiktok" in (parsed.hostname or "")
        else "https://www.instagram.com/"
        if "instagram" in (parsed.hostname or "") or "fbcdn" in (parsed.hostname or "")
        else f"{parsed.scheme}://{parsed.netloc}/"
    )
    resp = requests.get(
        url,
        headers={"User-Agent": DESKTOP_UA, "Referer": referer},
        stream=True,
        timeout=25,
    )
    if not resp.ok:
        raise HTTPException(status_code=502, detail="Media source could not be reached.")

    headers = {
        "Access-Control-Allow-Origin": "*",
        "Cross-Origin-Resource-Policy": "cross-origin",
    }
    if inline != "1":
        clean_name = re.sub(r"[^\w.\- ]+", "_", filename)
        headers["Content-Disposition"] = f'attachment; filename="{clean_name}"'

    return StreamingResponse(
        resp.iter_content(chunk_size=65536),
        media_type=resp.headers.get("Content-Type", "application/octet-stream"),
        headers=headers,
    )


@app.post("/api/extract")
def extract_route(payload: ExtractRequest):
    prune_cache()
    route = detect_platform_and_route(payload.url, payload.mode or "post", payload.platform)
    platform = route["platform"]
    is_profile = route["routeType"] == "profile"
    handle = route["handle"]

    if platform == "instagram":
        extracted = extract_instagram(route["url"], is_profile, handle)
    elif platform == "tiktok":
        extracted = extract_tiktok(route["url"], is_profile, handle)
    elif platform == "youtube":
        extracted = extract_youtube(route["url"], is_profile, handle)
    else:
        extracted = extract_pinterest(route["url"], is_profile, handle)

    media = extracted.get("media") or []
    if not media:
        raise HTTPException(
            status_code=422,
            detail="We couldn’t retrieve this public post. It may be private, expired, or temporarily unavailable.",
        )

    result_type = "image"
    if is_profile or all(m.get("type") == "profile" for m in media):
        result_type = "profile"
    elif extracted.get("isCarousel"):
        result_type = "carousel"
    elif any(m.get("type") == "video" for m in media):
        result_type = "video"

    download_id = uuid.uuid4().hex
    RESULT_CACHE[download_id] = {
        "createdAt": time.time(),
        "media": media,
        "creator": extracted["creator"],
        "audioUrl": extracted.get("audioUrl"),
        "title": extracted["title"],
    }

    return {
        "downloadId": download_id,
        "status": "success",
        "platform": platform,
        "type": result_type,
        "mediaType": extracted.get("mediaType"),
        "title": extracted["title"],
        "caption": extracted["caption"],
        "description": extracted["caption"],
        "uploadDate": extracted.get("uploadDate"),
        "boardName": None,
        "hashtags": extract_hashtags(extracted["caption"], extracted["title"]),
        "thumbnail": extracted.get("thumbnail"),
        "audioUrl": (
            build_stream_url(extracted["audioUrl"], safe_filename(f"{extracted['title']}-audio", "mp3"), False)
            if extracted.get("audioUrl")
            else None
        ),
        "creator": extracted["creator"],
        "media": media,
        "audioAvailable": extracted.get("audioAvailable", False),
    }


@app.post("/api/highlight")
def highlight_route(payload: HighlightRequest):
    prune_cache()
    raw_url = payload.url.strip()
    if not raw_url.startswith("http"):
        raw_url = f"https://{raw_url}"
    resolved = unshorten_url(raw_url)

    host = (urlparse(resolved).hostname or "").lower()
    if "instagram.com" not in host and "instagr.am" not in host:
        raise HTTPException(status_code=400, detail="Instagram Stories and Highlights links are supported here.")

    target = parse_story_target(resolved)
    if not target:
        raise HTTPException(
            status_code=400,
            detail="Paste an Instagram Story (/stories/username/…) or Highlight (/stories/highlights/… or /s/…) link.",
        )

    download_id = uuid.uuid4().hex
    title = "Instagram Highlight" if target["kind"] == "highlight" else f"@{target['username']}'s Story"
    creator: Dict[str, Any] = {
        "handle": target["username"],
        "name": target["username"],
        "avatarUrl": None,
        "profileUrl": f"https://www.instagram.com/{target['username']}/" if target["username"] else None,
        "verified": False,
    }

    unavailable_msg = (
        "This story or highlight is private, expired, or temporarily unavailable. "
        "Make sure the creator's account is public and active."
    )

    def unavailable() -> Dict[str, Any]:
        return {
            "downloadId": download_id,
            "title": title,
            "cover": None,
            "creator": creator,
            "stories": [],
            "truncated": False,
            "requiresDirectLinkAlert": True,
            "alertMessage": unavailable_msg,
        }

    fetched = fetch_instagram_story_media(target)
    if not fetched:
        return unavailable()

    if fetched.get("title"):
        title = fetched["title"]
    c = fetched.get("creator")
    if c:
        creator["handle"] = c.get("handle") or creator["handle"]
        creator["name"] = c.get("name") or creator["name"] or creator["handle"]
        creator["verified"] = bool(c.get("verified"))
        creator["profileUrl"] = c.get("profileUrl") or creator["profileUrl"]
        if c.get("avatarUrl"):
            creator["avatarUrl"] = build_stream_url(c["avatarUrl"], f"{creator['handle'] or 'creator'}-avatar.jpg", True)

    stories: List[Dict[str, Any]] = []
    media: List[Dict[str, Any]] = []
    today = time.strftime("%Y-%m-%d")

    for it in [i for i in fetched["items"] if not is_placeholder_asset(i["url"])]:
        idx = len(stories)
        n = idx + 1
        is_vid = it["type"] == "video"
        ext = "mp4" if is_vid else "jpg"
        stream_u = build_stream_url(it["url"], f"story-{n}.{ext}", True)
        dl_u = build_stream_url(it["url"], safe_filename(f"{title}-story-{n}", ext), False)
        thumb = (
            build_stream_url(it["thumbnail"], f"story-thumb-{n}.jpg", True)
            if it.get("thumbnail")
            else (None if is_vid else stream_u)
        )
        stories.append({
            "storyNumber": n,
            "mediaIndex": idx,
            "type": it["type"],
            "duration": it.get("duration") or (15 if is_vid else None),
            "thumbnail": thumb,
            "createdAt": it.get("takenAt") or today,
            "url": stream_u,
            "downloadUrl": dl_u,
        })
        media.append({
            "url": stream_u,
            "rawUrl": it["url"],
            "downloadUrl": dl_u,
            "thumbnail": thumb,
            "type": "video" if is_vid else "image",
            "quality": "Direct CDN video · MP4" if is_vid else "Direct CDN photo · High-res",
            "format": ext,
            "width": 1080,
            "height": 1920,
            "aspectRatio": "vertical",
            "hasAudio": is_vid,
        })

    if not stories:
        return unavailable()

    cover = (
        build_stream_url(fetched["cover"], "cover.jpg", True)
        if fetched.get("cover") and not is_placeholder_asset(fetched["cover"])
        else next((s["thumbnail"] for s in stories if s["thumbnail"]), None)
    )

    RESULT_CACHE[download_id] = {
        "createdAt": time.time(),
        "sourceUrl": target["canonicalUrl"],
        "platform": "instagram",
        "media": media,
        "creator": creator,
        "title": title,
        "stories": stories,
    }

    return {
        "downloadId": download_id,
        "title": title or (f"@{creator['handle']}'s Stories" if creator.get("handle") else "Instagram Stories"),
        "cover": cover,
        "creator": creator,
        "stories": stories,
        "truncated": False,
        "requiresDirectLinkAlert": False,
        "source": fetched["engine"],
    }


@app.post("/api/download")
def download_route(payload: DownloadRequest):
    if payload.assetType == "archive":
        items = payload.items or []
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for idx, item in enumerate(items):
                u = item.get("url")
                if not u:
                    continue
                try:
                    r = requests.get(u, headers={"User-Agent": DESKTOP_UA}, timeout=20)
                    if r.ok:
                        ext = "mp4" if item.get("type") == "video" else "jpg"
                        zf.writestr(item.get("filename") or f"slide-{idx+1}.{ext}", r.content)
                except Exception:
                    continue
        buf.seek(0)
        return Response(
            content=buf.getvalue(),
            media_type="application/zip",
            headers={"Content-Disposition": 'attachment; filename="omnidownloader-slides.zip"'},
        )

    cached = RESULT_CACHE.get(payload.downloadId) if payload.downloadId else None
    target_url = payload.url
    media_list = cached.get("media", []) if cached else []
    idx = payload.mediaIndex if payload.mediaIndex is not None else 0

    if not target_url and cached:
        if media_list and idx < len(media_list):
            target_url = media_list[idx].get("rawUrl") or media_list[idx].get("url")

    if not target_url:
        raise HTTPException(status_code=404, detail="Media URL not found.")

    if is_generic_instagram_logo(target_url):
        raise HTTPException(status_code=400, detail="Cannot download static logo assets. Story media is not directly downloadable.")

    is_yt = ("youtube.com" in target_url or "youtu.be" in target_url or (cached and cached.get("platform") == "youtube"))
    clean_name = safe_filename(payload.filename or "media", "mp4")

    if is_yt:
        yt_bin = "/bin/yt-dlp" if os.path.exists("/bin/yt-dlp") else (os.path.abspath("bin/yt-dlp") if os.path.exists("bin/yt-dlp") else "yt-dlp")
        src_url = (cached.get("sourceUrl") if cached else None) or target_url
        if payload.assetType == "audio" or payload.format == "mp3":
            tmp_audio = f"/tmp/omni-py-audio-{uuid.uuid4().hex}.mp3"
            cmd = [
                yt_bin,
                "-f", "bestaudio/best",
                "-x",
                "--audio-format", "mp3",
                "--audio-quality", "320k",
                "--ffmpeg-location", "/usr/bin/ffmpeg",
                "--extractor-args", "youtube:player_client=android,web",
                "--no-warnings",
                "-o", tmp_audio,
                src_url,
            ]
            subprocess.run(cmd, timeout=120)
            if os.path.exists(tmp_audio):
                fname = clean_name if clean_name.endswith(".mp3") else f"{clean_name.rsplit('.', 1)[0]}.mp3"
                return FileResponse(tmp_audio, media_type="audio/mpeg", filename=fname)
        else:
            media_item = media_list[idx] if media_list and idx < len(media_list) else None
            target_height = media_item.get("height") if media_item else None
            format_spec = (
                f"bestvideo[height<={target_height}]+bestaudio/best[ext=mp4]/best"
                if target_height
                else "bestvideo+bestaudio/best[ext=mp4]/best"
            )
            tmp_vid = f"/tmp/omni-py-vid-{uuid.uuid4().hex}.mp4"
            cmd = [
                yt_bin,
                "-f", format_spec,
                "--merge-output-format", "mp4",
                "--ffmpeg-location", "/usr/bin/ffmpeg",
                "--extractor-args", "youtube:player_client=android,web",
                "--no-warnings",
                "-o", tmp_vid,
                src_url,
            ]
            subprocess.run(cmd, timeout=180)
            if os.path.exists(tmp_vid):
                fname = clean_name if clean_name.endswith(".mp4") else f"{clean_name.rsplit('.', 1)[0]}.mp4"
                return FileResponse(tmp_vid, media_type="video/mp4", filename=fname)

    if payload.assetType == "audio" or payload.format == "mp3":
        tmp_audio = f"/tmp/omni-py-audio-{uuid.uuid4().hex}.mp3"
        try:
            subprocess.run(
                ["/usr/bin/ffmpeg", "-i", target_url, "-vn", "-acodec", "libmp3lame", "-b:a", "320k", "-y", tmp_audio],
                timeout=60,
                check=True,
            )
            if os.path.exists(tmp_audio):
                fname = clean_name if clean_name.endswith(".mp3") else f"{clean_name.rsplit('.', 1)[0]}.mp3"
                return FileResponse(tmp_audio, media_type="audio/mpeg", filename=fname)
        except Exception:
            pass

    r = requests.get(target_url, headers={"User-Agent": DESKTOP_UA}, timeout=25)
    if not r.ok:
        raise HTTPException(status_code=502, detail="Could not download media.")
    return Response(
        content=r.content,
        media_type=r.headers.get("Content-Type", "application/octet-stream"),
        headers={"Content-Disposition": f'attachment; filename="{clean_name}"'},
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
